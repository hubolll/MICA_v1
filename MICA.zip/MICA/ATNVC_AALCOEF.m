function ATNVC_AALCOEF
clc
clear
global NApath
global CBFpath
global aalmap
global Outputpath
global output_name

datafdir=CBFpath;
dataddir=NApath;
listf=dir([datafdir,filesep,'*.nii']);
lista=dir([aalmap,filesep,'*.nii']);
listd=dir([dataddir,filesep,'*.nii']);
outputdir = Outputpath
o = output_name
z = []
for i = 1:length(lista);
    AAL=[aalmap,filesep,lista(i).name];
volmask=spm_vol(AAL);
imgmask=spm_read_vols(volmask);
%imgmask(isnan(imgmask))=0;
cd(datafdir)
     for s=1:length(listf);
    subjname=listf(s).name;
    vol_cbf=spm_vol([datafdir,filesep,subjname]);
    img_cbf=spm_read_vols(vol_cbf);
    img_cbf(isnan(img_cbf)) = 0;
    %img_cbf(isnan(img_cbf))=0;
    img_cbf=double(img_cbf).*double(imgmask);
    a=img_cbf;
   cd(dataddir);
    subjnamed=subjname;
    vol_dc=spm_vol([dataddir,filesep,subjnamed]);
    img_dc=spm_read_vols(vol_dc);
    %img_cbf(isnan(img_cbf))=0;
    img_dc(isnan(img_dc)) = 0;
    img_dc=double(img_dc).*double(imgmask);
     b=img_dc;
     coef = corrcoef(a,b);
    coe = coef(2,1);
   
    z(s,i) = coe;
    cd(datafdir);
   disp(['Calculating the coupling value in ROI_',mat2str(i),'-subject_',mat2str(s)]);
      end
end
cd(outputdir)
xlswrite(['AAL_',o,'.xlsx'],z)
disp('The analysis was successfully conducted');